# Sistema Leads MVP

CRM de prospecção e relacionamento comercial: quadro Kanban de leads, importação de contatos, busca de empresas, campanhas de WhatsApp pela **API oficial** (só para contatos que autorizaram) e autoresponder com IA que passa para uma pessoa quando necessário.

> **Status: fase 2 de 10 (leads + Kanban).**
> Fase 1 (login e layout) aprovada. A fase 2 foi escrita sem poder instalar os pacotes no ambiente de criação: a lógica (telefone, deduplicação, mover cartões, opt-in/opt-out, gravação em arquivo) foi executada e conferida com 72 testes, mas as telas só rodam de verdade no seu computador. Se aparecer algum erro, copie a mensagem inteira para corrigirmos.

## O que já funciona

**Fase 1**
- Criar conta, entrar e sair (modo simulação: contas guardadas em um arquivo local).
- Menu lateral recolhível e layout responsivo em português do Brasil.

**Fase 2**
- **Kanban** com 6 etapas (Prospecção → Novo → Contatado → Respondeu → Reunião agendada → Fechado/Perdido): arraste os cartões entre colunas e a posição fica gravada. No celular, use a lista "Mover para…" de cada cartão.
- **Leads**: criar, editar, excluir, buscar e filtrar por etapa e por autorização.
- **Telefone** guardado no formato internacional (E.164) e **sem duplicados**: o mesmo número em formatos diferentes é reconhecido como o mesmo lead.
- **Opt-in / opt-out** de marketing, com data e origem registradas. Quem pede para sair nunca mais recebe marketing. Quem não tem autorização aparece como bloqueado para campanhas.
- **Histórico** de cada lead (criação, mudança de etapa, notas, edições e autorizações) e **tags**.
- Testes automáticos de senha, sessão, login, telefone, ordenação, regras de leads e datas.

## Como rodar no seu computador

### 1. Instale o Node.js (uma vez)

1. Abra **nodejs.org** e baixe a versão **LTS** (botão verde).
2. Instale clicando em "Next" até o fim.
3. Abra o terminal (Windows: tecla Windows, digite `PowerShell`, Enter. Mac: Cmd+Espaço, digite `Terminal`).
4. Digite `node --version` e Enter. Deve aparecer um número como `v22.x.x`. A versão precisa ser 20 ou maior.

### 2. Abra a pasta do projeto no terminal

Descompacte o arquivo `sistema-leads-mvp.zip`. No terminal, entre na pasta (troque o caminho pelo seu):

```
cd C:\Users\SeuNome\Downloads\sistema-leads-mvp
```

Dica: no Windows, abra a pasta no Explorador, clique na barra de endereço, digite `powershell` e Enter. O terminal já abre na pasta certa.

### 3. Instale as peças do projeto

```
npm install
```

Leva alguns minutos e mostra muita coisa na tela. É normal. Avisos amarelos ("warn") podem ser ignorados.

### 4. Crie o arquivo de configuração

Windows (PowerShell):

```
Copy-Item .env.example .env.local
```

Mac/Linux:

```
cp .env.example .env.local
```

Depois gere um segredo para o login:

```
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copie o texto que aparecer, abra o arquivo `.env.local` em um editor (o Bloco de Notas serve) e cole depois de `SESSION_SECRET=`. Salve. **Esse arquivo nunca vai para o GitHub.**

### 5. Ligue o sistema

```
npm run dev
```

Abra **http://localhost:3000** no navegador. Para desligar, volte ao terminal e aperte `Ctrl+C`.

## Comandos úteis

| Comando | Para que serve |
|---|---|
| `npm run dev` | Liga o sistema para você usar e testar |
| `npm test` | Roda os testes automáticos (tudo deve ficar verde) |
| `npm run lint` | Procura erros de estilo no código |
| `npm run typecheck` | Confere os tipos do TypeScript |
| `npm run build` | Gera a versão final, como a que vai para a internet |

## Modo simulação

Com `MOCK_MODE=true` (o padrão) o sistema funciona **sem nenhuma chave** de serviço externo. Os dados de teste ficam dentro da pasta do projeto, em `.data/` (esta pasta não vai para o GitHub): contas em `.data/users.json` e leads em `.data/leads.json`. Para apagar tudo e recomeçar do zero, apague a pasta `.data`.

## Estrutura de pastas

```
sistema-leads-mvp/
├── CLAUDE.md                 regras do projeto (conformidade, fases)
├── .env.example              modelo do arquivo de configuração
├── src/
│   ├── app/
│   │   ├── (auth)/           telas de entrar e criar conta
│   │   └── (app)/            telas do sistema (exigem login)
│   │       ├── kanban/       quadro Kanban
│   │       └── leads/        lista, novo lead, detalhes e ações do servidor
│   ├── components/           menu lateral, Kanban, formulário de lead, botões, campos
│   └── lib/
│       ├── auth/             login (adaptador de simulação; Supabase depois)
│       ├── leads/            regras dos leads, repositório (arquivo local; Supabase depois)
│       ├── phone.ts          telefone no formato E.164
│       ├── security.ts       senhas e cookie de sessão
│       └── nav.ts            lista de seções do menu
└── tests/                    testes automáticos (Vitest)
```

## Segurança

- Senhas guardadas só como hash (scrypt), nunca em texto.
- Cookie de login assinado (HMAC), `httpOnly`, com validade de 7 dias.
- Chaves ficam em `.env.local`, que o `.gitignore` bloqueia. Antes de publicar no GitHub, rode `git status` e confirme que `.env.local` e `.data` **não** aparecem na lista.

## Aviso de conformidade (LGPD e Meta)

Este projeto foi desenhado para usar apenas caminhos oficiais:

- WhatsApp **somente** pela WhatsApp Cloud API da Meta, com templates aprovados.
- Mensagens de marketing **só** para contatos com autorização (opt-in) registrada, com opção de sair ("SAIR").
- Não automatiza curtir, seguir ou comentar no Instagram.

O autor não é advogado. Para uso comercial, consulte alguém de compliance.

## Próximas fases

~~2 leads + Kanban~~ (feita) · 3 importação CSV · 4 busca de empresas · 5 campanhas + fila · 6 caixa de entrada + autoresponder · 7 agendador · 8 WhatsApp real · 9 painel · 10 Instagram (opcional).

## Licença

MIT. Edite o arquivo `LICENSE` e troque `SEU NOME AQUI` pelo seu nome.
