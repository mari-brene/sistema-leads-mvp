import { config } from "@/lib/config";
import { mockLeadsRepository, type LeadsRepository } from "./mock-repository";

export type { ImportManyResult, LeadsRepository } from "./mock-repository";

/** Escolhe onde os leads ficam guardados: arquivo local agora, Supabase na fase de contas reais. */
export function getLeadsRepository(): LeadsRepository {
  if (config.mockMode) return mockLeadsRepository;

  throw new Error(
    "MOCK_MODE=false exige o repositório do Supabase, que será adicionado na fase de contas reais. " +
      "Por enquanto deixe MOCK_MODE=true no arquivo .env.local.",
  );
}
